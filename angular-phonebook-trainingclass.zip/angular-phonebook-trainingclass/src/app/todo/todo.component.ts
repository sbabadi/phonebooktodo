import { Component, OnInit } from '@angular/core';
import { TodoService } from './todo.service';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.scss']
})
export class TodoComponent implements OnInit {

  todos: any[] = [];
  loading: boolean = true;
  constructor(private ts: TodoService) { }

  ngOnInit() {
    this.ts.getAllTodo().then((res: any) => {
      this.todos = res;
      setTimeout(() => {
        this.loading = false;
      }, 1000);
    }
    )
  }

}
