import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InstertDataComponent } from './instert-data.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [InstertDataComponent],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports: [InstertDataComponent],
  providers: []
})
export class InstertDataModule { }
