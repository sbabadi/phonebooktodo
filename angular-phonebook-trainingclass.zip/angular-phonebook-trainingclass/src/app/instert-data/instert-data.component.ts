import { Component, OnInit } from '@angular/core';
import { LocalStorageService } from '../services/localstorage.service';
import { PhoneBookData } from './data.model';

@Component({
  selector: 'app-instert-data',
  templateUrl: './instert-data.component.html',
  styleUrls: ['./instert-data.component.css']
})
export class InstertDataComponent implements OnInit {

  dataSource: PhoneBookData[] = []
  data: PhoneBookData = {
    name: "",
    lastName: "",
    phone: 0,

  };
  constructor(private ls: LocalStorageService) { }

  ngOnInit() {
    const lsData: any = this.ls.get("DATA");
    this.dataSource = lsData

    console.log(this.dataSource);

  }

  handleSubmitData() {
    const { name, lastName, phone } = this.data;
    if (name !== "" && lastName !== "" && phone !== 0) {
      this.dataSource.push(this.data)

    } else {
      alert("Please fill the from")
    }


  }

  handleSyncData() {
    if (this.dataSource.length) {
      //  localStorage.setItem("DATA", JSON.stringify(this.dataSource))
      this.ls.set("DATA", this.dataSource)
    } else {
      alert("There is no data for sync")
    }
  }

  onItemClick(item: PhoneBookData) {
    alert(`Info is: ${item.email}, ${item.address}`)
  }

}
