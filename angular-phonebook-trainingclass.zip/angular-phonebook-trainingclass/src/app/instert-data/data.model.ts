export interface PhoneBookData {
    name: string,
    lastName: string,
    phone: number,
    email?: string,
    address?: string
}